# RBLX Outfit Viewer — backend

Backend Cloudflare Worker pour le visualiseur 3D.

## Pourquoi un backend ?

Roblox protège désormais les endpoints de miniatures 3D (`assets-thumbnail-3d` et `users/avatar-3d`) avec une clé Open Cloud/API key ou OAuth. La clé ne doit jamais être mise dans le JavaScript public de GitHub Pages.

## Installation

1. Installer Node.js.
2. Dans ce dossier :

```bash
npm install -g wrangler
wrangler login
```

3. Créer une clé Roblox Open Cloud avec le droit **thumbnails / read**.
4. Ajouter la clé comme secret :

```bash
npx wrangler secret put ROBLOX_API_KEY
```

5. Déployer :

```bash
npx wrangler deploy
```

Cloudflare affichera une URL du type `https://rblx-outfit-viewer-api.<ton-compte>.workers.dev`.

Copie cette URL dans les paramètres du site, champ **URL du backend 3D**.

## Sécurité

La clé Roblox reste côté Worker et n'est jamais envoyée au navigateur.
