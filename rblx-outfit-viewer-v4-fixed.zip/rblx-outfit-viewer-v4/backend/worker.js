const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'public, max-age=300'
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', ...extra }
  });
}

function hashHost(hash) {
  let i = 31;
  for (let t = 0; t < Math.min(38, hash.length); t++) i ^= hash.charCodeAt(t);
  const n = ((i % 8) + 8) % 8;
  return `https://t${n}.rbxcdn.com/${hash}`;
}

function corsHeaders(extra = {}) {
  return { ...CORS, ...extra };
}

async function roblox(url, env, options = {}) {
  const headers = new Headers(options.headers || {});
  if (env.ROBLOX_API_KEY) headers.set('x-api-key', env.ROBLOX_API_KEY);
  return fetch(url, { ...options, headers });
}

async function userByUsername(username) {
  const r = await fetch('https://users.roblox.com/v1/usernames/users', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: false })
  });
  if (!r.ok) throw new Error(`users API ${r.status}`);
  const j = await r.json();
  const u = j.data?.[0];
  if (!u) throw new Error('Utilisateur Roblox introuvable');
  return u;
}

async function itemInfo(id) {
  const r = await fetch('https://catalog.roblox.com/v1/catalog/items/details', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ items: [{ itemType: 'Asset', id: Number(id) }] })
  });
  if (!r.ok) throw new Error(`catalog API ${r.status}`);
  const j = await r.json();
  const item = j.data?.[0];
  if (!item) throw new Error('Item introuvable');

  let image = null;
  const t = await fetch(`https://thumbnails.roblox.com/v1/assets?assetIds=${id}&returnPolicy=PlaceHolder&size=420x420&format=Png&isCircular=false`);
  if (t.ok) image = (await t.json()).data?.[0]?.imageUrl || null;

  return {
    id: Number(id),
    name: item.name || `Item ${id}`,
    assetType: item.assetType || '',
    creatorName: item.creatorName || '',
    creatorType: item.creatorType || '',
    creatorTargetId: item.creatorTargetId || null,
    price: item.price ?? null,
    image
  };
}

async function threeDFromThumbnailResponse(firstResponse, env) {
  if (!firstResponse.ok) {
    const text = await firstResponse.text();
    throw new Error(`3D API ${firstResponse.status}: ${text.slice(0, 300)}`);
  }
  const first = await firstResponse.json();
  const entry = first.data?.[0] || first;
  if (!entry?.imageUrl) throw new Error(`3D model non disponible (${entry?.state || 'unknown'})`);

  const modelResponse = await roblox(entry.imageUrl, env);
  if (!modelResponse.ok) throw new Error(`3D model file ${modelResponse.status}`);
  const model = await modelResponse.json();

  if (!model.obj || !model.mtl) throw new Error('Modèle 3D incomplet');

  const objResponse = await fetch(hashHost(model.obj));
  const mtlResponse = await fetch(hashHost(model.mtl));
  if (!objResponse.ok || !mtlResponse.ok) throw new Error('Impossible de récupérer le modèle 3D');

  const obj = await objResponse.text();
  let mtl = await mtlResponse.text();

  // Roblox MTL files reference texture hashes. Rewrite them to our CORS-safe proxy.
  const hashes = new Set(model.textures || []);
  for (const hash of hashes) {
    const escaped = hash.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    mtl = mtl.replace(new RegExp(`(^|\\s)${escaped}(?=\\s|$)`, 'g'), `$1/api/cdn/${hash}`);
  }

  return {
    obj,
    mtl,
    textures: [...hashes],
    camera: model.camera || null,
    aabb: model.aabb || null
  };
}

async function asset3d(id, env) {
  const r = await roblox(`https://thumbnails.roblox.com/v1/assets-thumbnail-3d?assetId=${encodeURIComponent(id)}`, env);
  return threeDFromThumbnailResponse(r, env);
}

async function avatar3d(userId, env) {
  const r = await roblox(`https://thumbnails.roblox.com/v1/users/avatar-3d?userId=${encodeURIComponent(userId)}`, env);
  return threeDFromThumbnailResponse(r, env);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders() });

    const url = new URL(request.url);
    const path = url.pathname;

    try {
      if (path === '/api/health') return json({ ok: true, service: 'RBLX Outfit Viewer API' });

      if (path.startsWith('/api/user/')) {
        const username = decodeURIComponent(path.slice('/api/user/'.length));
        const u = await userByUsername(username);
        return json(u);
      }

      if (path.startsWith('/api/item/')) {
        const id = path.slice('/api/item/'.length).replace(/\D/g, '');
        if (!id) return json({ error: 'ID invalide' }, 400);
        return json(await itemInfo(id));
      }

      if (path.startsWith('/api/asset-3d/')) {
        const id = path.slice('/api/asset-3d/'.length).replace(/\D/g, '');
        if (!id) return json({ error: 'ID invalide' }, 400);
        return json(await asset3d(id, env), 200, { 'Cache-Control': 'public, max-age=3600' });
      }

      if (path.startsWith('/api/avatar-3d/')) {
        const id = path.slice('/api/avatar-3d/'.length).replace(/\D/g, '');
        if (!id) return json({ error: 'ID invalide' }, 400);
        return json(await avatar3d(id, env), 200, { 'Cache-Control': 'public, max-age=600' });
      }

      if (path.startsWith('/api/cdn/')) {
        const hash = path.slice('/api/cdn/'.length).replace(/[^a-zA-Z0-9_-]/g, '');
        if (!hash) return new Response('Bad hash', { status: 400, headers: corsHeaders() });
        const r = await fetch(hashHost(hash));
        if (!r.ok) return new Response('CDN error', { status: r.status, headers: corsHeaders() });
        const headers = corsHeaders({ 'Cache-Control': 'public, max-age=86400' });
        headers['Content-Type'] = r.headers.get('content-type') || 'application/octet-stream';
        return new Response(r.body, { status: r.status, headers });
      }

      return json({ error: 'Route inconnue' }, 404);
    } catch (error) {
      return json({ error: error?.message || 'Erreur serveur' }, 500);
    }
  }
};
