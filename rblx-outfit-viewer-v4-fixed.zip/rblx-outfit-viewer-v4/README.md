# RBLX Outfit Viewer — V4

Projet complet :

- `frontend/index.html` : site GitHub Pages, stockage local, historique, recherche, filtres, dossiers, thèmes, sauvegarde/import et visualiseur 3D.
- `backend/worker.js` : Cloudflare Worker qui garde la clé Roblox côté serveur et récupère les modèles 3D Roblox.

## Architecture

GitHub Pages → Cloudflare Worker → APIs Roblox

La clé Roblox n'est jamais placée dans `index.html`.

## Mise en ligne

### 1. Frontend

Remplace ton ancien `index.html` GitHub Pages par `frontend/index.html`.

### 2. Backend

Dans `backend/` :

```bash
npm install -g wrangler
wrangler login
npx wrangler secret put ROBLOX_API_KEY
npx wrangler deploy
```

La clé doit être une clé Roblox Open Cloud autorisant `thumbnails` en lecture.

### 3. Relier le site au backend

Dans le site : **Paramètres → URL du backend 3D**.

Colle l'URL `workers.dev` fournie par Cloudflare, sans slash final.

## Ce que fait réellement le visualiseur

- Item seul : récupère et affiche le modèle 3D de l'asset Roblox.
- Mon avatar : récupère le modèle 3D public de l'utilisateur Roblox.
- R6/R15 : affiche un mannequin 3D R6/R15 local et peut charger l'asset 3D à côté pour inspection.

L'application ne prétend pas appliquer arbitrairement tous les UGC sur un rig : Roblox ne fournit pas un endpoint public permettant de transformer directement un avatar en « avatar + n'importe quel item » sans gérer la structure d'avatar, les accessoires rigides et les vêtements superposables. Le rendu d'un vrai avatar et d'un vrai asset 3D est néanmoins réel.
